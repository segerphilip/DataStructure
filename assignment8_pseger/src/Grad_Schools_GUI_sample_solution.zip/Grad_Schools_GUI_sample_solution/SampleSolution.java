public class SampleSolution {

  public static void main(String[] args) {
    GradSchoolsGUI.main(args);
  }
  
}

